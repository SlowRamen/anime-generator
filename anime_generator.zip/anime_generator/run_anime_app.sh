#!/bin/zsh
cd ~/Desktop/anime_generator
/Library/Frameworks/Python.framework/Versions/3.13/bin/streamlit run anime_generator.py
